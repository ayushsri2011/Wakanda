package com.nightcrawler.popularmovies;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class stage3 extends AppCompatActivity {

    ArrayList<CustomPojo> data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_detail);

        Intent intent = getIntent();

        Bundle args = intent.getBundleExtra("BUNDLE");
        data = (ArrayList<CustomPojo>)args.getSerializable("ARRAYLIST");

        ImageView poster=(ImageView)findViewById(R.id.poster);
        TextView title=(TextView)findViewById(R.id.title);
        TextView vote_average=(TextView)findViewById(R.id.vote_average);
        TextView releaseDate=(TextView)findViewById(R.id.releaseDate);
        TextView synopsis=(TextView)findViewById(R.id.synopsis);

//        int pos=args.getInt("total_pages");
        String base_image_url="https://image.tmdb.org/t/p/w500";
        String poster_path=data.get(0).getPosterPath();
        String url  =   base_image_url  +   poster_path;
        Picasso.get().load(url).placeholder(R.drawable.ph).into(poster);

        title.setText(data.get(0).getTitle());
        vote_average.setText("User Rating: "+data.get(0).getVoteAverage());
        releaseDate.setText("Release Date: "+data.get(0).getReleaseDate());
        synopsis.setText(data.get(0).getOverview());



    }
}
