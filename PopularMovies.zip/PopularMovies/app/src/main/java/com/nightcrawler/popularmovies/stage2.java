package com.nightcrawler.popularmovies;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class stage2 extends AppCompatActivity {

    RecyclerView recyclerView;    CustomAdapter adapter;    ImageView picture;
    Button button_next;Button button_prev;
    int search_type,page;
    int total_pages=0;
//    protected ArrayList<CustomPojo> listContentArr= new ArrayList<>();
    protected ArrayList<CustomPojo> movieList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();

        Bundle args = intent.getBundleExtra("BUNDLE");
         movieList = (ArrayList<CustomPojo>)args.getSerializable("ARRAYLIST");

        recyclerView=(RecyclerView)findViewById(R.id.bohe);
        picture =(ImageView)findViewById(R.id.picture);

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter=new CustomAdapter(this);
        populateRecyclerViewValues(movieList);

        total_pages=args.getInt("total_pages");
        search_type=args.getInt("search_type");
        page=args.getInt("page");
        button_next=(Button)findViewById(R.id.next_button);
        button_prev=(Button)findViewById(R.id.prev_button);

        button_prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!checkConnectivity()) {    alert();    }
                else
                {
                    if(page==1)
                    {
                        alert2();
                    }
                    else
                    {
                        page--;
                    }
                    String ty="";
                    if(search_type==0)
                       ty="top_rated";
                    else
                        ty="popular";

                    String address_temp = commonFunctions.generateAddress(ty,page);
                    query q=new query();

                    try {
                        q.execute(address_temp).get();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }

                    try {
                        jsonProcessing c=new jsonProcessing(q.local_response);
                         movieList=c.process();
                        populateRecyclerViewValues(movieList);



                    } catch (JSONException e) {
                        Log.v("searchResult","Error in fetching details from JSON response received");
                        e.printStackTrace();
                    }


                }}
        });




        button_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!checkConnectivity()) {    alert();    }
                else
                {
                    if(page==total_pages)
                    {
                        alert3();
                    }
                    else
                    {
                        page++;
                    }
                    String ty="";
                    if(search_type==0)
                        ty="top_rated";
                    else
                        ty="popular";

                    String address_temp = commonFunctions.generateAddress(ty,page);
                    query q=new query();

                    try {
                        q.execute(address_temp).get();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                    try {
                        jsonProcessing c=new jsonProcessing(q.local_response);
                        movieList=c.process();
                        populateRecyclerViewValues(movieList);



                    } catch (JSONException e) {
                        Log.v("searchResult","Error in fetching details from JSON response received");
                        e.printStackTrace();
                    }


                }}
        });











//        button_next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(!checkConnectivity())
//                {
//                    alert();
//                }else
//                {
//                    searchResult("popular");
//                    Log.d(TAG,"Search Type is- popularity");
//                }}
//        });













    }

    private void populateRecyclerViewValues(ArrayList<CustomPojo> movieList) {
//          for(int iter=1;iter<=20;iter++) {
            //Creating POJO class object
            CustomPojo pojoObject = new CustomPojo();
            //Values are binded using set method of the POJO class
//            pojoObject.setName("Ayush" + iter);
//            pojoObject.setContent("Hello RecyclerView! item: "+iter);
//            pojoObject.setTime("10:45PM");
            //After setting the values, we add all the Objects to the array
            //Hence, listConentArr is a collection of Array of POJO objects
//            listContentArr.add(pojoObject);
//        }
        //We set the array to the adapter
//        adapter.setListContent(listContentArr);
        adapter.setListContent(movieList);

        //We in turn set the adapter to the RecyclerView
        recyclerView.setAdapter(adapter);
    }




    public boolean checkConnectivity(){
        ConnectivityManager conMgr =  (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conMgr.getActiveNetworkInfo();
        if (netInfo == null){
            return false;
        }else{
            return true;
        }
    }

    public void alert()
    {

        new AlertDialog.Builder(this)
                .setTitle(getResources().getString(R.string.app_name))
                .setMessage(getResources().getString(R.string.internet_error))
                .setPositiveButton("OK", null).show();
    }

    public void alert2()
    {
        new AlertDialog.Builder(this)
                .setTitle(getResources().getString(R.string.app_name))
                .setMessage("This is the first page")
                .setPositiveButton("OK", null).show();
    }

    public void alert3()
    {
        new AlertDialog.Builder(this)
                .setTitle(getResources().getString(R.string.app_name))
                .setMessage("This is the last page")
                .setPositiveButton("OK", null).show();
    }

}




//            for(int i=0;i<movieList.size();i++)
//            System.out.println("stage2:::"+movieList.get(i).getTitle());










//        test=(TextView)findViewById(R.id.test);
//
//        test.setText(movieList.get(5).getTitle());


//        int search_type=intent.getIntExtra("search_type",80);
//        Toast.makeText(this, "search_type " + search_type, Toast.LENGTH_SHORT).show();
//        Bundle args = intent.getBundleExtra("BUNDLE");
//        ArrayList<Object> object = (ArrayList<Object>) args.getSerializable("ARRAYLIST");


//        ArrayList<HashMap<String, String>> details = (ArrayList<HashMap<String, String>>) getIntent().getSerializableExtra("details");
//        for(int i=0;i<5;i++)
//        test.append(details.get(6).get("title"));


//        Toast.makeText(this, details.get(1).get("title"), Toast.LENGTH_SHORT).show();
//        Toast.makeText(this, details.get(2).get("overview"), Toast.LENGTH_SHORT).show();