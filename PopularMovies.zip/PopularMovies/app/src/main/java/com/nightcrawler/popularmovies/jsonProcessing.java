package com.nightcrawler.popularmovies;


import android.util.Log;import org.json.JSONArray;import org.json.JSONException;
import org.json.JSONObject;import java.util.ArrayList;import java.util.HashMap;

public class jsonProcessing {

    String response;

    jsonProcessing(String r)   {        this.response=r;    }

    public ArrayList<CustomPojo> process() throws JSONException {
//        public ArrayList<HashMap<String,String>> process() throws JSONException {
//        ArrayList<HashMap<String, String>> movieList = new ArrayList();

        ArrayList<CustomPojo> movieList = new ArrayList();

        HashMap<String, String> movie = new HashMap<>();
//        CustomPojo cp=new CustomPojo();
        try {
            JSONObject jsonObj = new JSONObject(response);            // Getting JSON Array node
            JSONArray results = jsonObj.getJSONArray("results");
            // looping through All results

            System.out.println("Length of Result::"+results.length());
            for (int i = 0; i < results.length(); i++) {
                JSONObject c = results.getJSONObject(i);

                String poster_path = c.getString("poster_path");
                String title = c.getString("title");
                String release_date = c.getString("release_date");
                String overview = c.getString("overview");
                String vote_average = c.getString("vote_average");

                CustomPojo cp=new CustomPojo();
                cp.setPosterPath(poster_path);
                cp.setReleaseDate(release_date);
                cp.setTitle(title);
                cp.setVoteAverage(vote_average);
                cp.setOverview(overview);



                movieList.add(cp);



            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }

        System.out.println("Ayush"+movieList);
        return movieList;




    }



    public int getTotalPages() throws JSONException {
        JSONObject temp = new JSONObject(response);

        return Integer.parseInt(temp.getString("total_pages"));
    }




}







//                Log.v("Poster====",cp.getPosterPath());
//                Log.v("Title====",cp.getTitle());
//                movie.put("poster_path", poster_path);
//                Log.v("poster_path", poster_path);
//                movie.put("release_date", release_date);
//                Log.v("release_date", release_date);
//                movie.put("title", title);
//                Log.v("title", title);
//                movie.put("vote_average", vote_average);
//                Log.v("vote_average", vote_average);
//                movie.put("overview", overview);
//                Log.v("overview", overview);
