package com.nightcrawler.popularmovies;


import android.content.Intent;
import android.util.Log;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;import android.view.View;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String address=""; String responseJSON;
    private static final String TAG = MainActivity.class.getSimpleName();
    int page=1;
    ImageView imageView;TextView rating;TextView title;TextView releaseDate;TextView synopsis;
    ProgressBar pb;
    Button button_topRated;    Button button_popular;
    int search_type=-1;// Zero means by Top rated. One means Popular.
    int total_pages=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_page);

        LinearLayout layout =(LinearLayout) findViewById(R.id.back);
        layout.setBackgroundResource(R.drawable.backpiq);
        pb=(ProgressBar)findViewById(R.id.loadingdata_progress);



        button_topRated=(Button)findViewById(R.id.button_topRated); button_popular=(Button)findViewById(R.id.button_popular);
//        button_topRated.setEnabled(true);
//        button_popular.setEnabled(true);
           button_topRated.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pb.setVisibility(View.VISIBLE);

                    if(!checkConnectivity()) {
                        alert();
                        pb.setVisibility(View.INVISIBLE);
                    }
                    else{
                        button_topRated.setEnabled(false);
                        pb.setVisibility(View.VISIBLE);
                        search_type=0;
                        searchResult("top_rated",page);
                        Log.d(TAG,"Search Type is- topRated");
                    }
                    }
            });

           button_popular.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(!checkConnectivity())
                {
                    alert();
                    pb.setVisibility(View.INVISIBLE);
                }else
                {
                    button_popular.setEnabled(false);
                    pb.setVisibility(View.VISIBLE);
                    search_type=1;
                    searchResult("popular",page);
                    Log.d(TAG,"Search Type is- popularity");
                }}
            });

    }


    public void searchResult(String type, int page) {

        try {
            Log.v(TAG, "searchResult: Type is--" + type);
            address = commonFunctions.generateAddress(type,page);
            Log.v("Address---",address);

            query q=new query();
            q.execute(address).get();
            responseJSON=q.local_response;

            ArrayList<CustomPojo> movieList;
            String jsonStr = responseJSON;
            if(jsonStr=="")
            {
                if(!checkConnectivity())
                  alert();
                else
                Toast.makeText(this,"Error in fetching data from Network", Toast.LENGTH_SHORT).show();
            }
            else {
                Log.v("searchResult","responseJSON is not null");
                try {
                    jsonProcessing c=new jsonProcessing(jsonStr);
                    movieList=c.process();
                    total_pages=c.getTotalPages();
                    Intent intent = new Intent(this, stage2.class);
                    Bundle args = new Bundle();
                    args.putSerializable("ARRAYLIST",(Serializable)movieList);
                    args.putInt("search_type",search_type);
                    args.putInt("page",page);
                    args.putInt("total_pages",total_pages);
                    intent.putExtra("BUNDLE",args);

                    button_popular.setEnabled(true);
                    button_topRated.setEnabled(true);
                    pb.setVisibility(View.INVISIBLE);

                    startActivity(intent);
                } catch (JSONException e) {
                    Log.v("searchResult","Error in fetching details from JSON response received");
                    e.printStackTrace();
                }
            }

        } catch (Exception e) {
            Log.v("Error in searchResult","");
            e.printStackTrace();
        }
    }
    public boolean checkConnectivity(){
        ConnectivityManager conMgr =  (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = conMgr.getActiveNetworkInfo();
        if (netInfo == null){
            return false;
        }else{
            return true;
        }
    }
    public void alert(){

        new AlertDialog.Builder(MainActivity.this)
                .setTitle(getResources().getString(R.string.app_name))
                .setMessage(getResources().getString(R.string.internet_error))
                .setPositiveButton("OK", null).show();
    }
    }






//        progress=(ProgressBar)findViewById(R.id.indeterminateBar);
//        progress.setVisibility(View.INVISIBLE);


//                        Intent intent= new Intent(this,stage2.class);
//                        intent.putExtra("search_type", search_type);
//                        intent.putExtra("details",ArrayList<HashMap>movieList);
//                        startActivity(intent);



//                    String temp=movieList.get(0).getTitle();

//                    JSONObject jsonObj = new JSONObject(jsonStr);

// Getting JSON Array node
//                    JSONArray results = jsonObj.getJSONArray("results");

// looping through All results
//                    for (int i = 0; i < results.length(); i++) {
//                        JSONObject c = results.getJSONObject(i);

//                        String poster_path = c.getString("poster_path");
//                        String title = c.getString("title");
//                        String release_date = c.getString("release_date");
//                        String overview = c.getString("overview");
//                        String vote_average = c.getString("vote_average");

// tmp hash map for single contact
//                        HashMap<String, String> movie = new HashMap<>();

// adding each child node to HashMap key => value
//                        movie.put("poster_path", poster_path);
//                        Log.v("poster_path", poster_path);
//                        movie.put("release_date", release_date);
//                        Log.v("release_date", release_date);
//                        movie.put("title", title);
//                        Log.v("title", title);
//                        movie.put("vote_average", vote_average);
//                        Log.v("vote_average", vote_average);
//                        movie.put("overview", overview);
//                        Log.v("overview", overview);

// adding movies to movie list
//                        movieList.add(movie);
//                    }

//            int k=0;//introducing deliberate delay to wait till Async task is finished
//    int test=0;
//            for(;k<900000000;k++)
//                if(test==1)
//                    break;
//            for(k=0;k<100000000;)
//                k++;

