package com.nightcrawler.popularmovies;

public class commonFunctions {


    public static String  generateAddress(String search_type, int page)
    {
    String address = "http://api.themoviedb.org/3/movie/" + search_type + "?api_key=9498a03d3c2c3de6b0eb1504be02bc9e" + "&page=" + page;
    return address;
    }










}
