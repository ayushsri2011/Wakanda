package com.nightcrawler.popularmovies;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class query extends AsyncTask<String, String,String> {

    public String local_response;
    public int test;




    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        String line="";
        HttpURLConnection connection = null;                                       //Log.v("Connection",connection.toString());
        BufferedReader reader = null;                                              //Log.v("reader",reader.toString());
        String local_address=params[0];
        local_response="";
        Log.v("Address is---",local_address);
        try {
            URL url= new URL(local_address);                                           Log.v("url",url.toString());
//                URL url = params[0];
            connection = (HttpURLConnection) url.openConnection();
            Log.v("Connection",connection.toString());
            connection.connect();

            InputStream stream = connection.getInputStream();
            Log.v("stream",stream.toString());

            reader = new BufferedReader(new InputStreamReader(stream));
            Log.v("reader",reader.toString());

            StringBuilder builder = new StringBuilder();
            Log.v("buffer",builder.toString());

            int i=1;
            line = reader.readLine();
            builder.append(line+"\n");

//                while ((line = reader.readLine()) != null) {
//                    i++;
//                    buffer.append(line+"\n");
//                    if(i==2)
//                        break;
//                }

            local_response=line;
//            responseJSON=line;

//                if(responseJSON==null)
//                Toast.makeText(MainActivity.this, ""+responseJSON+"is null", Toast.LENGTH_SHORT).show();

        } catch (MalformedURLException e){                e.printStackTrace();
        } catch (IOException e){                          e.printStackTrace();
        } catch(NullPointerException e){                  e.printStackTrace();
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                Log.v("close","UNABLE TO CLOSE READER");
                e.printStackTrace();
            }
        }
        return line;
    }


    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
//            if(result!=null){
//            Toast.makeText(MainActivity.this, result  , Toast.LENGTH_SHORT).show();
//            }
        Log.v("onPostExecute:::",result);


//        WeakReference<String> t=new WeakReference<>(result);
//        activity.onBackgroundTaskCompleted(result);

//            return result;
//            masthead.setText("responseJSON is null");

//        test=1;//end delay



    }
}





//    Activity activity;

//    query (Activity activity) {
//        this.activity = activity;
//    }


//    WeakReference<Activity> mWeakActivity;
//    query(Activity activity)
//    {
//        mWeakActivity = new WeakReference<Activity>(activity);
//    }